#!/bin/sh
source /koolshare/scripts/base.sh
/koolshare/serverchan/serverchan_dhcp_trigger
